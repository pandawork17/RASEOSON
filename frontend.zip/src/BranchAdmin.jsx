// src/pages/BranchAdmin.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './BranchAdmin.css';

// ==========================================
// 기존 커스텀 드롭다운 
// ==========================================
function CustomDropdown({ currentStatus, onStatusChange, statusStyles }) {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (status) => {
    onStatusChange(status);
    setIsOpen(false);
  };

  const currentStyle = statusStyles[currentStatus] || { bg: '#f3f4f6', text: '#333' };

  return (
    <div style={{ position: 'relative', display: 'inline-block' }}>
      <div
        onClick={() => setIsOpen(!isOpen)}
        style={{
          padding: '5px 12px',
          borderRadius: '12px',
          fontWeight: 'bold',
          cursor: 'pointer',
          backgroundColor: currentStyle.bg,
          color: currentStyle.text,
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          fontSize: '13px',
          border: `1px solid ${currentStyle.text}33`
        }}
      >
        {currentStatus} <span style={{ fontSize: '10px' }}>▼</span>
      </div>

      {isOpen && (
        <div style={{
          position: 'absolute',
          top: '100%',
          left: 0,
          marginTop: '5px',
          backgroundColor: 'white',
          border: '1px solid #ccc',
          borderRadius: '8px',
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
          zIndex: 10,
          width: '130px',
          overflow: 'hidden'
        }}>
          {Object.keys(statusStyles).map(status => (
            <div
              key={status}
              onClick={() => handleSelect(status)}
              style={{
                padding: '10px',
                cursor: 'pointer',
                fontWeight: 'bold',
                color: statusStyles[status].text,
                backgroundColor: 'white',
                borderBottom: '1px solid #eee',
                fontSize: '13px',
                textAlign: 'center'
              }}
              onMouseEnter={(e) => e.target.style.backgroundColor = '#f9f9f9'}
              onMouseLeave={(e) => e.target.style.backgroundColor = 'white'}
            >
              {status}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ==========================================
// 💡 통합된 본사 공지사항 전용 컴포넌트
// ==========================================
const API_URL = "http://127.0.0.1:8000";

const brownButton = {
  background: "#796252",
  color: "#fff",
  border: 0,
  padding: "8px 16px",
  cursor: "pointer",
  borderRadius: 4,
  fontWeight: "bold"
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  marginTop: 8,
  padding: 12,
  border: "1px solid #CDBFAF",...