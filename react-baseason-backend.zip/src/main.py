from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# 💡 프론트엔드 서버가 백엔드에 접근할 수 있도록 허용하는 설정 (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 모든 주소에서의 접근을 허용합니다 (개발용)
    allow_credentials=True,
    allow_methods=["*"],  # GET, POST 등 모든 요청 방식을 허용합니다
    allow_headers=["*"],  # 모든 헤더 정보를 허용합니다
)

@app.get("/")
def read_root():
    return {"message": "백엔드 서버가 성공적으로 작동 중입니다!"}

# 💡 프론트엔드에 보내줄 샘플 데이터 API
@app.get("/api/data")
def get_data():
    return {
        "status": "success",
        "items": ["사과", "바나나", "오렌지"],
        "version": "1.0.0"
    }
