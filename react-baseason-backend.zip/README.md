# React Baseason Backend

FastAPI로 구현한 백엔드 서버입니다.

## 실행 방법

### 1. 프로젝트 폴더로 이동

PowerShell에서 백엔드 프로젝트 루트로 이동합니다.

```powershell
cd C:\baseason\react-baseason-backend
```

### 2. 의존성 설치 및 동기화

`pyproject.toml`에 정의된 의존성을 설치합니다.

```powershell
uv sync
```

### 3. 개발 서버 실행

FastAPI 앱을 개발 모드로 실행합니다. 코드가 변경되면 서버가 자동으로 다시 시작됩니다.

```powershell
uv run uvicorn src.main:app --reload
```

기본적으로 서버는 다음 주소에서 실행됩니다.

- 서버: http://127.0.0.1:8000
- API 문서: http://127.0.0.1:8000/docs
- 대체 API 문서: http://127.0.0.1:8000/redoc

### 4. API 확인

브라우저에서 다음 주소를 열어 응답을 확인할 수 있습니다.

- `GET /`: 서버 상태 확인
- `GET /api/data`: 샘플 데이터 조회

예시:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/
Invoke-RestMethod http://127.0.0.1:8000/api/data
```

### 5. 서버 종료

서버가 실행 중인 터미널에서 `Ctrl+C`를 누릅니다.

## 참고

- 명령어는 반드시 `pyproject.toml`이 있는 `react-baseason-backend` 폴더에서 실행합니다.
- `uv`가 설치되어 있지 않다면 [uv 공식 설치 문서](https://docs.astral.sh/uv/getting-started/installation/)를 참고하세요.
