from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# MySQL 접속 정보 (아이디:비밀번호@주소:포트/데이터베이스명)
SQLALCHEMY_DATABASE_URL = "mysql+pymysql://shopdbid2:shopdbid2@127.0.0.1:3306/shopdb2"

# DB 엔진 생성
engine = create_engine(SQLALCHEMY_DATABASE_URL)

# DB 세션 로컬 클래스 생성
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base 모델 클래스 생성
Base = declarative_base()

# 제너레이터 함수: API 호출 시마다 DB 세션을 생성하고 완료 후 닫아줌
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()