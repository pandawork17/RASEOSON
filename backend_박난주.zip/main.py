from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import text
import models
from database import get_db

app = FastAPI(
    title="SHOPDB2 도매인B API",
    version="1.0.0",
    description="판매자 프로필, 카테고리, 상품 마스터, 상품 옵션 및 이미지, 지점별 재고 API"
)

# CORS 설정 (개발 환경에서는 모든 출처 허용으로 임시 설정하여 문제 원인 파악)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # 모든 도메인 허용 (실제 서비스에서는 특정 도메인만 허용해야 함)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["default"])
def root():
    return {"message": "SHOPDB2 API Server is running!"}

@app.get("/health/db", tags=["default"])
def database_health_check(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {str(e)}")

@app.get("/api/products/categories", tags=["도매인B 상품 및 카테고리"])
def get_categories(db: Session = Depends(get_db)):
    return db.query(models.Category).all()

@app.get("/api/products", tags=["도매인B 상품 및 카테고리"])
def get_products(db: Session = Depends(get_db)):
    return db.query(models.Product).all()

# 단일 상품 상세 조회 엔드포인트
@app.get("/api/products/{product_id}", tags=["도매인B 상품 및 카테고리"])
def get_product_detail(product_id: int, db: Session = Depends(get_db)):
    product = db.query(models.Product).filter(models.Product.product_id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # 해당 상품의 옵션(variants)도 함께 가져옴
    variants = db.query(models.ProductVariant).filter(models.ProductVariant.product_id == product_id).all()
    
    # JSON 형태로 상품 정보와 옵션 정보를 묶어서 반환
    return {
        "product": product,
        "variants": variants
    }

@app.get("/api/inventories/{org_id}/{variant_id}", tags=["도매인B 지점별 재고"])
def get_inventory(org_id: int, variant_id: int, db: Session = Depends(get_db)):
    inventory = db.query(models.Inventory).filter(
        models.Inventory.org_id == org_id,
        models.Inventory.variant_id == variant_id
    ).first()
    if not inventory:
        raise HTTPException(status_code=404, detail="Inventory not found")
    return inventory